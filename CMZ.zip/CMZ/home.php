<?php
    session_start();
    include("db/db_connection.php");
    include("include/header.php");
?>



	 <!-- ****** Banner Area ****** -->
	
	<div class="container">	
	<div class="row">
			
            	
        
     			<img src="img/blog-img/banner.jpg"  alt="avtar" class="responsive1" height="200px" width="1024px">
                       
			
</div></div>
 <!-- ****** Banner Area End ****** -->

    <!-- ****** Welcome Post Area Start ****** -->
   <section class="archive-area section_padding_80">
        <div class="container">
			
            <div class="row">

                <!-- Single Post -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-post wow fadeInUp" data-wow-delay="0.1s">
                        <!-- Post Thumb -->
                        <div class="post-thumb">
                            <img src="img/blog-img/1.jpg" alt="" heigh="10px">
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-meta d-flex">
                                <div class="post-author-date-area d-flex">
                                    <!-- Post Author -->
                                    <div class="post-author">
                                       <a>Launched Date</a>
                                    </div>
                                    <!-- Post Date -->
                                    <div class="post-date">
                                        <a href="#">May 19, 2019</a>
                                    </div>
                                </div>
                                <!-- Post Comment & Share Area -->
                                
                            </div>
                           
                                <h5>Newly launched Ear Phones With warranty </h5>
                            
                        </div>
                    </div>
                </div>
				
				<!-- Single Post -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-post wow fadeInUp" data-wow-delay="0.1s">
                        <!-- Post Thumb -->
                        <div class="post-thumb">
                            <img src="img/blog-img/7.jpg" alt="" heigh="10px">
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-meta d-flex">
                                <div class="post-author-date-area d-flex">
                                    <!-- Post Author -->
                                    <div class="post-author">
                                       <a>Launched Date</a>
                                    </div>
                                    <!-- Post Date -->
                                    <div class="post-date">
                                        <a href="#">May 19, 2019</a>
                                    </div>
                                </div>
                                <!-- Post Comment & Share Area -->
                                
                            </div>
                           
                                <h5>Newly launched 2 in 1 Iphone Charging & Data Transfer Cable </h5>
                            
                        </div>
                    </div>
                </div>
				
				<!-- Single Post -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-post wow fadeInUp" data-wow-delay="0.1s">
                        <!-- Post Thumb -->
                        <div class="post-thumb">
                            <img src="img/blog-img/9.jpg" alt="" heigh="10px">
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-meta d-flex">
                                <div class="post-author-date-area d-flex">
                                    <!-- Post Author -->
                                    <div class="post-author">
                                       <a>Launched Date</a>
                                    </div>
                                    <!-- Post Date -->
                                    <div class="post-date">
                                        <a href="#">May 19, 2019</a>
                                    </div>
                                </div>
                                <!-- Post Comment & Share Area -->
                                
                            </div>
                           
                                <h5>Newly launched Power Bank 1600Mah with 9 Month Warantty Specilly for Iphone & Ipads </h5>
                            
                        </div>
                    </div>
                </div>
				<div class="col-12 col-md-6 col-lg-4">
                    <div class="single-post wow fadeInUp" data-wow-delay="0.1s">
                        <!-- Post Thumb -->
                        <div class="post-thumb">
                            <img src="img/blog-img/10.jpg" alt="" heigh="10px">
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-meta d-flex">
                                <div class="post-author-date-area d-flex">
                                    <!-- Post Author -->
                                    <div class="post-author">
                                       <a>Launched Date</a>
                                    </div>
                                    <!-- Post Date -->
                                    <div class="post-date">
                                        <a href="#">May 25, 2019</a>
                                    </div>
                                </div>
                                <!-- Post Comment & Share Area -->
                                
                            </div>
                           
                                <h5>Smart Charger </h5>
                            
                        </div>
                    </div>
                </div>
				<div class="col-12 col-md-6 col-lg-4">
                    <div class="single-post wow fadeInUp" data-wow-delay="0.1s">
                        <!-- Post Thumb -->
                        <div class="post-thumb">
                            <img src="img/blog-img/11.jpg" alt="" heigh="10px">
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-meta d-flex">
                                <div class="post-author-date-area d-flex">
                                    <!-- Post Author -->
                                    <div class="post-author">
                                       <a>Launched Date</a>
                                    </div>
                                    <!-- Post Date -->
                                    <div class="post-date">
                                        <a href="#">May 19, 2019</a>
                                    </div>
                                </div>
                                <!-- Post Comment & Share Area -->
                                
                            </div>
                           
                                <h5>Newly launched Universal Charger With 300 MAH Power With warranty </h5>
                            
                        </div>
                    </div>
                </div>
				<div class="col-12 col-md-6 col-lg-4">
                    <div class="single-post wow fadeInUp" data-wow-delay="0.1s">
                        <!-- Post Thumb -->
                        <div class="post-thumb">
                            <img src="img/blog-img/6.jpg" alt="" heigh="10px">
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-meta d-flex">
                                <div class="post-author-date-area d-flex">
                                    <!-- Post Author -->
                                    <div class="post-author">
                                       <a>Launched Date</a>
                                    </div>
                                    <!-- Post Date -->
                                    <div class="post-date">
                                        <a href="#">May 19, 2019</a>
                                    </div>
                                </div>
                                <!-- Post Comment & Share Area -->
                                
                            </div>
                           
                                <h5>Newly launched Multi Charger With One Year Warantty. 3 Chargings Slots Same Time with Same Power	</h5>
                            
                        </div>
                    </div>
                </div>
				
				
			</div>
		</div>
	</section>
    <!-- ****** Welcome Area End ****** -->

  

   

    <?php
    
    include("include/footer.php");
?>