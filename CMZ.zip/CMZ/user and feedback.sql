-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 03, 2019 at 11:22 PM
-- Server version: 5.6.40-84.0-log
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ictatjcu_ecomm`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `fname`, `lname`, `email`, `rating`, `comment`, `created_at`, `updated_at`) VALUES
(1, 'gagan', 'deep', 'ss@gmail.com', 'Bad', 'dsfsadfasdf', NULL, NULL),
(2, 'gagan', 'deep', 'ss@gmail.com', 'Bad', 'dsfsadfasdf', NULL, NULL),
(3, 'gagan', 'deep', 'ss@gmail.com', 'Bad', 'dsfsadfasdf', NULL, NULL),
(4, 'gaganarora', 'arora', 'aa@gmail.com', 'Excellent', 'overall good', NULL, NULL),
(5, 'gaganarora', 'arora', 'aa@gmail.com', 'Excellent', 'overall good', NULL, NULL),
(6, 'gaganarora', 'arora', 'aa@gmail.com', 'Excellent', 'overall good', NULL, NULL),
(7, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(8, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(9, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(10, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(11, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(12, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(13, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(14, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(15, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(16, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL),
(17, 'hh', 'jj', 'hj@gmail.com', 'Bad', 'hello how r u', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phno` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `contractor_type` varchar(255) DEFAULT NULL COMMENT 'this field is only for contractor to know the type of contractor'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `phno`, `password`, `img_url`, `role`, `created_at`, `updated_at`, `contractor_type`) VALUES
(0, 'gagan', 'deep', 'gg@gmail.com', '0000', 'aassdd', NULL, 'customer', NULL, NULL, NULL),
(0, 'gagannaroraa', 'ss', 'ss@gmail.com', '000', 'aassdd', NULL, 'customer', NULL, NULL, NULL),
(0, 'gagannaroraa', 'ss', 'ss@gmail.com', '000', 'aassdd', NULL, 'customer', NULL, NULL, NULL),
(0, 'gagan', 'deep', 'g123@gmail.com', '233232', '', NULL, 'customer', NULL, NULL, NULL),
(0, 'ARSHDEEP', 'KUMAR', 'KUMARARSH81@GMAIL.COM', '8437466990', '', NULL, 'customer', NULL, NULL, NULL),
(0, 'arshdeep ', 'kumar', 'kumararsh81@gmail.com', '8437466990', '', NULL, 'customer', NULL, NULL, NULL),
(0, 'Ggg', 'Aaa', 'aa@gmail.com', '888', '', NULL, 'customer', NULL, NULL, NULL),
(0, 'rajiv', 'ra', 'ra@gmail.com', '0000', '', NULL, 'customer', NULL, NULL, NULL),
(0, 'aaa', 'ss', 'aass@gmail.com', '1111', '1111', NULL, 'customer', NULL, NULL, NULL),
(0, 'tt', 'yy', 't@gmail.com', '123', '123', NULL, 'customer', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
