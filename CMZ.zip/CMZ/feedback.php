<?php
    session_start();
    include("db/db_connection.php");
    include("include/header.php");
	include("include/header2.php");

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
      $fname = $_POST['firstname'];
      $lname = $_POST['lastname'];
      $email = $_POST['email'];
      $rating = $_POST['rating'];
      $comment =$_POST['comment'];
      $current_time = date("Y-m-d h:i:sa");
      $query = "INSERT INTO feedback(fname, lname, email, rating, comment) "
              . "VALUES('$fname', '$lname', '$email', '$rating', '$comment')";
  //Database Entry
      mysqli_query($con, $query);
      mysqli_close($con);
  }
?>


 <!--==========================
      Feedback Section
    ============================-->
    <!-- ****** Banner Area ****** -->
	
           
               
                    <div class="bradcumb-title text-center">
                        <h2>Customer Feedback</h2>
          <p>Please provide your feedback!</p>
                    </div><br>
             
	
 <!-- ****** Banner Area End ****** -->
	

    <!-- ****** Welcome Post Area Start ****** -->
 
        <div class="container">
			
         
                <div class="signup-content">
                    <div class="signup-form">
                        
                        <form action="" method="POST" class="register-form" id="register-form">
                            <div class="form-group">
                                <label for="username"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="firstname" id="firstname" placeholder="Your First Name"/>
                            </div>
							<div class="form-group">
                                <label for="username"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="lastname" id="lastname" placeholder="Your Last Name"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"/>
                            </div>
							 <div class="form-group">
                                <label for="comment"><i class="zmdi zmdi-email"></i></label>
                                <input type="textarea" name="comment" id="email" placeholder="Your Comments"/>
                            </div>
							
                            <div class="form-group ">
            <p>How do you rate your overall experience?</br>
              <input type="radio" name="rating" value="Bad" required> Bad 
              <input type="radio" name="rating" value="Average" required> Average
              <input type="radio" name="rating" value="Good" required> Good  
              <input type="radio" name="rating" value="Excellent" required> Excellent
            </p>
			</div>
             
			  
			 
              
                            <div class="form-group form-button">
                                <input type="submit" name="submit" type= "submit" id="submit" class="form-submit" />
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
						<figure><img src="images/feedback.jpg" alt="sign up image"></figure>
					<!-- ______________________________________________________Displaying the data from database ______________________________-->
		
                    </div>
                </div>
            
      
  </div><!-- #feedback -->
  </main>
<?php
 
		
         
    include("include/footer.php");
?>

