<?php
    session_start();
    include("db/db_connection.php");
      include("include/header.php");
    
    include("include/header2.php");
    
    $is_login_failed = FALSE;
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){

        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $query = "SELECT * FROM users WHERE email='$username' AND password='$password' and role!='admin' LIMIT 1";
        $result = mysqli_query($con, $query);
        $row = mysqli_fetch_row($result);
        
        if ($row != null) {
            $_SESSION['fname'] = $row[1];
            $_SESSION['lname'] = $row[2];
            $_SESSION['email'] = $row[3];
            $_SESSION['id'] = $row[0];
            $_SESSION['role'] = $row[7];
            
            mysqli_close($con);
            header('location:index.php');
        }else{
           $is_login_failed = TRUE;
           mysqli_close($con);
        }
    }
    
    include("includes/header.php");
?>



    <!-- ****** Welcome Post Area Start ****** -->
 
        <div class="container">
			
         
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                        <a href="register.php" class="signup-image-link">Create an account</a>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Sign In</h2>
						<?php if($is_login_failed){ ?>
            <div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Error!</strong> Wrong username or password.
            </div>
          <?php } ?>
                        <form action="login.php" method="post" name="login_form" role="form" class="contactForm" class="register-form" >
                            <div class="form-group">
							<label for="username"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="email" class="form-control" name="username" id="email" placeholder="Your Email" required />
                            </div>
                            <div class="form-group">
							 <label for="password_1"><i class="zmdi zmdi-lock"></i></label>
                                 <input type="password" class="form-control" name="password" id="password" placeholder="Your Password"  required />
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit"  class="form-submit" />
                            </div>
                        </form>
                        <div class="social-login">
                            <span class="social-label">Or login with</span>
                            <ul class="socials">
							
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-facebook"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-twitter"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-google"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            
        
  </div>
				
				
		
    <!-- ****** Welcome Area End ****** -->
<?php
    
    include("include/footer.php");
?>